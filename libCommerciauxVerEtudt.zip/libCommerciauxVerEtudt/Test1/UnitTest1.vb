Imports Microsoft.VisualStudio.TestTools.UnitTesting

Namespace Test1
    <TestClass>
    Public Class UnitTest1
        <TestMethod>
        Sub TestSub()

        End Sub
    End Class
End Namespace

